from flask import Blueprint, render_template, request


grammars = Blueprint('grammars', __name__, static_folder='static', template_folder='templates', url_prefix='/grammars')


@grammars.route('/')
def grammars_home():
    title = "Hellogrammars | Words formation"
    return render_template('grammars/home.html', title=title)


@grammars.route('/words-formation')
def words_formation():
    title = "Hellogrammars | Words formation"
    return render_template('grammars/home.html',title=title)


@grammars.route('/the-sentence')
def the_sentence():
    title = "Hellogrammars | The sentence "
    return render_template('grammars/the_sentence.html', title=title)


@grammars.route('/kinds-of-sentence')
def kinds_of_sentence():
    title = "Hellogrammars | Kinds of sentence "
    return render_template('grammars/kinds_of_sentence.html', title=title)


@grammars.route('/parts-of-speech')
def parts_of_speech():
    title = "Hellogrammars | Parts of speech "
    return render_template('grammars/parts_of_speech.html', title=title)


@grammars.route('/kinds-of-noun')
def kinds_of_nouns():
    title = "Hellogrammars | Kinds of nouns "
    return render_template('grammars/kinds_of_nouns.html', title=title)


@grammars.route('/countable-and-uncountable-nouns')
def countable_and_uncountable_nouns():
    title = "Hellogrammars | Countable and uncountable nouns "
    return render_template('grammars/countable_and_uncountable_nouns.html', title=title)


@grammars.route('/the-noun-number')
def the_noun_number():
    title = "Hellogrammars | The noun : Number"
    return render_template('grammars/the_noun_number.html', title=title)


@grammars.route('/the-noun-gender')
def the_noun_gender():
    title = "Hellogrammars | The noun : Gender"
    return render_template('grammars/the_noun_gender.html', title=title)


@grammars.route('/the-noun-case')
def the_noun_case():
    title = "Hellogrammars | The noun : Case"
    return render_template('grammars/the_noun_case.html', title=title)


@grammars.route('/more-about-pronouns')
def more_about_pronouns():
    title = "Hellogrammars | More about pronouns"
    return render_template('grammars/more_about_pronouns.html', title=title)


@grammars.route('/more-about-adjectives')
def more_about_adjectives():
    title = "Hellogrammars | More about adjectives"
    return render_template('grammars/more_about_adjectives.html', title=title)


@grammars.route('/comparison-of-adjectives')
def comparison_of_adjectives():
    title = "Hellogrammars | Comparison of adjectives"
    return render_template('grammars/comparison_of_adjectives.html', title=title)


@grammars.route('/more-about-verbs-and-modal')
def more_about_verbs_and_modal():
    title = "Hellogrammars | More about verbs and modal"
    return render_template('grammars/more_about_verbs_and_modal.html', title=title)


@grammars.route('/conjugation-of-verbs')
def conjugation_of_verbs():
    title = "Hellogrammars | Conjugaion of verbs"
    return render_template('grammars/conjugation_of_verbs.html', title=title)


@grammars.route('/right-form-of-verbs')
def right_form_of_verbs():
    title = "Hellogrammars | Right form of verbs"
    return render_template('grammars/right_form_of_verbs.html', title=title)


@grammars.route('/subject-verb-agreement')
def subject_verb_agreement():
    title = "Hellogrammars | Subject and verb agreement"
    return render_template('grammars/subject_verb_agreement.html', title=title)


@grammars.route('/time-and-tense-with-mood')
def time_and_tense_with_mood():
    title = "Hellogrammars | Time and tens with mood"
    return render_template('grammars/time_and_tense_with_mood.html', title=title)


@grammars.route('/more-about-adverbs-and-adverbials')
def more_about_adverbs_and_adverbials():
    title = "Hellogrammars | More about adverbs and adverbials"
    return render_template('grammars/more_about_adverbs_and_adverbials.html', title=title)


@grammars.route('/more-about-prepositions')
def more_about_prepositions():
    title = "Hellogrammars | More about prepositions"
    return render_template('grammars/more_about_prepositions.html', title=title)


@grammars.route('/more-about-conjunctions')
def more_about_conjunctions():
    title = "Hellogrammars | More about conjunctions"
    return render_template('grammars/more_about_conjunctions.html', title=title)


@grammars.route('/more-about-interjections')
def more_about_interjections():
    title = "Hellogrammars | More about interjections"
    return render_template('grammars/more_about_interjections.html', title=title)


@grammars.route('/the-articles')
def the_articles():
    title = "Hellogrammars | The articles"
    return render_template('grammars/the_articles.html', title=title)


@grammars.route('/the-determiners')
def the_determiners():
    title = "Hellogrammars | The determiners"
    return render_template('grammars/the_determiners.html', title=title)


@grammars.route('/introductory-there-and-it')
def introductory_there_and_it():
    title = "Hellogrammars | Introductory there and it"
    return render_template('grammars/introductory_there_and_it.html', title=title)


@grammars.route('/mood')
def mood():
    title = "Hellogrammars | Mood"
    return render_template('grammars/mood.html', title=title)


@grammars.route('/tag-questions')
def tag_questions():
    title = "Hellogrammars | Tag questions"
    return render_template('grammars/tag_questions.html', title=title)


@grammars.route('/narration-reporting')
def narration_reporting():
    title = "Hellogrammars | Narration reporting"
    return render_template('grammars/narration_reporting.html', title=title)


@grammars.route('/voice-change-describing-a-process')
def voice_change_describing_a_process():
    title = "Hellogrammars | Voice change describing a process"
    return render_template('grammars/voice_change_describing_a_process.html', title=title)


@grammars.route('/linking-words')
def linking_words():
    title = "Hellogrammars | Linking words"
    return render_template('grammars/linking_words.html', title=title)


@grammars.route('/conditional-sentence')
def conditional_sentence():
    title = "Hellogrammars | Conditional sentence"
    return render_template('grammars/conditional_sentence.html', title=title)


@grammars.route('/transformation-of-sentences')
def transformation_of_sentence():
    title = "Hellogrammars | Transformation of sentences"
    return render_template('grammars/transformation_of_sentences.html', title=title)


@grammars.route('/completing-sentence')
def completing_sentence():
    title = "Hellogrammars | Completing sentence"
    return render_template('grammars/completing_sentence.html', title=title)


@grammars.route('/the-clause')
def the_clause():
    title = "Hellogrammars | The clause"
    return render_template('grammars/the_clause.html', title=title)

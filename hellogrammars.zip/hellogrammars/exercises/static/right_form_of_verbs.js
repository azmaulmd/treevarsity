(function() {
    function buildQuiz() {
        // variable to store the HTML output
        const output = [];

        // for each question...
        myQuestions.forEach(
            (currentQuestion, questionNumber) => {

                // variable to store the list of possible answers
                const answers = [];

                // and for each available answer...
                for (letter in currentQuestion.answers) {

                    // ...add an HTML radio button
                    answers.push(
                        `<label>
                <input type="radio" name="question${questionNumber}" value="${letter}">
                ${letter} :
                ${currentQuestion.answers[letter]}
              </label>`
                    );
                }

                // add this question and its answers to the output
                output.push(
                    `<div class="question"> ${currentQuestion.question} </div>
            <div style="padding-left:20px" class="answers"> ${answers.join('')} </div>`
                );
            }
        );

        // finally combine our output list into one string of HTML and put it on the page
        quizContainer.innerHTML = output.join('');
    }

    function showResults() {

        // gather answer containers from our quiz
        const answerContainers = quizContainer.querySelectorAll('.answers');

        // keep track of user's answers
        let numCorrect = 0;

        // for each question...
        myQuestions.forEach((currentQuestion, questionNumber) => {

            // find selected answer
            const answerContainer = answerContainers[questionNumber];
            const selector = `input[name=question${questionNumber}]:checked`;
            const userAnswer = (answerContainer.querySelector(selector) || {}).value;

            // if answer is correct
            if (userAnswer === currentQuestion.correctAnswer) {
                // add to the number of correct answers
                numCorrect++;

                // color the answers green
                answerContainers[questionNumber].style.color = 'green';

            }
            // if answer is wrong or blank
            else {
                // color the answers red
                answerContainers[questionNumber].style.color = 'red';
            }
        });

        // show number of correct answers out of total
        resultsContainer.innerHTML = ` You get ${numCorrect} out of ${myQuestions.length}`;
    }

    const quizContainer = document.getElementById('quiz');
    const resultsContainer = document.getElementById('results');
    const submitButton = document.getElementById('submit');
    const myQuestions = [{
            question: "1. Sometimes, he _______ out with his grandfather.",
            answers: {
                A: "Walks",
                B: "Walking",
                C: "Walked"
            },
            correctAnswer: "A"
        },
        {
            question: "2.	The children are ________ here and there.",
            answers: {
                A: "Run",
                B: "Runs",
                C: "Running"
            },
            correctAnswer: "C"
        },

        {
            question: "3.	I have ______ my homework.",
            answers: {
                A: "Do",
                B: "Done",
                C: "Did"
            },
            correctAnswer: "B"
        },

        {
            question: "4. So, she has _____ to me and has said that fact.",
            answers: {
                A: "Come",
                B: "Came",
                C: "Coming"
            },
            correctAnswer: "A"
        },
        {
            question: "5.	They______ football since they were primary school students.",
            answers: {
                A: "Plays",
                B: "Played",
                C: "Play"
            },
            correctAnswer: "C"
        },

        {
            question: "6.	I shall _____ to hospital to see my mother next day.",
            answers: {
                A: "Go",
                B: "Going",
                C: "Goes"
            },
            correctAnswer: "A"
        },

        {
            question: "7.	I want to_____to my boss.",
            answers: {
                A: "Talked",
                B: "Talk",
                C: "Talking"
            },
            correctAnswer: "B"
        },

        {
            question: "8.	I heard a story ______ fear in our mind.",
            answers: {
                A: "Making",
                B: "Made",
                C: "Makes"
            },
            correctAnswer: "A"
        },

        {
            question: "9.	This work was ___ by Farhan.",
            answers: {
                A: "Do",
                B: "Did",
                C: "Done"
            },
            correctAnswer: "C"
        },

        {
            question: "10.	She _______and told him that he had been lying.",
            answers: {
                A: "Refuse",
                B: "Refusing",
                C: "Refused"
            },
            correctAnswer: "C"
        },

        {
            question: "11.	The other members are______to urge about this decision.",
            answers: {
                A: "Goes",
                B: "Going",
                C: "Go"
            },
            correctAnswer: "B"
        },

        {
            question: "12.	The earth______round the sun.",
            answers: {
                A: "Moved",
                B: "Moving",
                C: "Moves"
            },
            correctAnswer: "A"
        },

        {
            question: "13.	Our liberation war______place in 1971 but, I was born in 1992.",
            answers: {
                A: "Take",
                B: "Takes",
                C: "Took"
            },
            correctAnswer: "B"
        },

        {
            question: "14.	Recently, we have______Sonargoan.",
            answers: {
                A: "Visiting",
                B: "Visit",
                C: "Visited"
            },
            correctAnswer: "C"
        },

        {
            question: "15.	Nipa hasn’t_____her homework.",
            answers: {
                A: "Done",
                B: "Did",
                C: "Do"
            },
            correctAnswer: "A"
        },

        {
            question: "16.	I ______my grandmother long since.",
            answers: {
                A: "See",
                B: "Saw",
                C: "Seen"
            },
            correctAnswer: "B"
        },

        {
            question: "17.	Tania and Mamun have been__________since morning.",
            answers: {
                A: "Reads",
                B: "Read",
                C: "Reading"
            },
            correctAnswer: "C"
        },

        {
            question: "18.	Nipa hasn’t______her homework.",
            answers: {
                A: "Done",
                B: "Do",
                C: "Did"
            },
            correctAnswer: "A"
        },
        {
            question: "19.	Without______hard, we can’t prosper in life.",
            answers: {
                A: "Works",
                B: "Working",
                C: "Worked"
            },
            correctAnswer: "B"
        },

        {
            question: "20. A_______ stone gathers no moss.",
            answers: {
                A: "Rolling",
                B: "Roll",
                C: "Rolled"
            },
            correctAnswer: "A"
        }



    ];

    // Kick things off
    buildQuiz();

    // Event listeners
    submitButton.addEventListener('click', showResults);
})();
(function() {
    function buildQuiz() {
        // variable to store the HTML output
        const output = [];

        // for each question...
        myQuestions.forEach(
            (currentQuestion, questionNumber) => {

                // variable to store the list of possible answers
                const answers = [];

                // and for each available answer...
                for (letter in currentQuestion.answers) {

                    // ...add an HTML radio button
                    answers.push(
                        `<label>
                <input type="radio" name="question${questionNumber}" value="${letter}">
                ${letter} :
                ${currentQuestion.answers[letter]}
              </label>`
                    );
                }

                // add this question and its answers to the output
                output.push(
                    `<div class="question"> ${currentQuestion.question} </div>
            <div style="padding-left:20px" class="answers"> ${answers.join('')} </div>`
                );
            }
        );

        // finally combine our output list into one string of HTML and put it on the page
        quizContainer.innerHTML = output.join('');
    }

    function showResults() {

        // gather answer containers from our quiz
        const answerContainers = quizContainer.querySelectorAll('.answers');

        // keep track of user's answers
        let numCorrect = 0;

        // for each question...
        myQuestions.forEach((currentQuestion, questionNumber) => {

            // find selected answer
            const answerContainer = answerContainers[questionNumber];
            const selector = `input[name=question${questionNumber}]:checked`;
            const userAnswer = (answerContainer.querySelector(selector) || {}).value;

            // if answer is correct
            if (userAnswer === currentQuestion.correctAnswer) {
                // add to the number of correct answers
                numCorrect++;

                // color the answers green
                answerContainers[questionNumber].style.color = 'green';

            }
            // if answer is wrong or blank
            else {
                // color the answers red
                answerContainers[questionNumber].style.color = 'red';
            }
        });

        // show number of correct answers out of total
        resultsContainer.innerHTML = ` You get ${numCorrect} out of ${myQuestions.length}`;
    }

    const quizContainer = document.getElementById('quiz');
    const resultsContainer = document.getElementById('results');
    const submitButton = document.getElementById('submit');
    const myQuestions = [{
            question: "1. I went to hospital with _____ view to seeing her as she was sick.",
            answers: {
                A: "A",
                B: "The",
                C: "An"
            },
            correctAnswer: "A"
        },
        {
            question: "2. The earth moves round ___ sun.",
            answers: {
                A: "A",
                B: "The",
                C: "An"
            },
            correctAnswer: "B"
        },
        {
            question: "3. I saw ____ lame man yesterday",
            answers: {
                A: "The",
                B: "A",
                C: "An"
            },
            correctAnswer: "C"

        },
        {
            question: "4.____poor is always unhappy.",
            answers: {
                A: "An",
                B: "A",
                C: "The"
            },
            correctAnswer: "C"

        },
        {
            question: "5. I bought ___ dozen of bananas.",
            answers: {
                A: "A",
                B: "The",
                C: "An"
            },
            correctAnswer: "A"

        },
        {
            question: "6. Javed stole _____ umbrella.",
            answers: {
                A: "A",
                B: "The",
                C: "An"
            },
            correctAnswer: "C"

        },
        {
            question: "7. What _____ awful behavior she did!",
            answers: {
                A: "An",
                B: "the",
                C: "A"
            },
            correctAnswer: "A"

        },
        {
            question: "8. Mr. David always put on ______ expensive and gorgeous dress.",
            answers: {
                A: "The",
                B: "An",
                C: "A"
            },
            correctAnswer: "B"

        },
        {
            question: "9. ____ moon is very charming at mid night",
            answers: {
                A: "An",
                B: "The",
                C: "A"
            },
            correctAnswer: "The"

        },
        {
            question: "10. The cow is _____ domestic animal.",
            answers: {
                A: "The",
                B: "An",
                C: "A"
            },
            correctAnswer: "A"

        },
        {
            question: "11. He is _____second boy in our class.",
            answers: {
                A: "A",
                B: "An",
                C: "The"
            },
            correctAnswer: "C"

        },
        {
            question: "12. ___taking of morning-exercise is good for health.",
            answers: {
                A: "The",
                B: "A",
                C: "An"
            },
            correctAnswer: "A"

        },
        {
            question: "13. ____yellow part of the egg is tasty.",
            answers: {
                A: "A",
                B: "The",
                C: "An"
            },
            correctAnswer: "B"

        },
        {
            question: "14. The great Akbar was ___mighty ruler. ",
            answers: {
                A: "A",
                B: "The",
                C: "An"
            },
            correctAnswer: "A"

        },

        {
            question: "15. Nazul is ____ Byron of Bangladesh ",
            answers: {
                A: "An",
                B: "The",
                C: "A"
            },
            correctAnswer: "B"
        },
        {
            question: "16. I know ___ man in red shirt.",
            answers: {
                A: "An",
                B: "The",
                C: "A"
            },
            correctAnswer: "B"
        },
        {
            question: "17. Nipa ate ____ guava.",
            answers: {
                A: "The",
                B: "A",
                C: "An"
            },
            correctAnswer: "B"
        },
        {
            question: "18. They are____same group of people.",
            answers: {
                A: "The",
                B: "An",
                C: "A"
            },
            correctAnswer: "A"
        },
        {
            question: "19. We can walk four miles___hour.",
            answers: {
                A: "A",
                B: "An",
                C: "The"
            },
            correctAnswer: "B"
        },
        {
            question: "20. We visit to my grandmother once ____ week.",
            answers: {
                A: "A",
                B: "The",
                C: "An"
            },
            correctAnswer: "A"
        },
        {
            question: "21. ____cow is a domestic animal.",
            answers: {
                A: "The",
                B: "A",
                C: "An"
            },
            correctAnswer: "B"
        },
        {
            question: "22. Mr. Gegrry is ____ M.B.B.S doctor.",
            answers: {
                A: "An",
                B: "The",
                C: "A"
            },
            correctAnswer: "A"
        },
        {
            question: "23. Mr. David always put on ____ expensive and gorgeous dress.",
            answers: {
                A: "A",
                B: "The",
                C: "An"
            },
            correctAnswer: "C"
        },
        {
            question: "24. The crow is ___ nasty bird.",
            answers: {
                A: "An",
                B: "A",
                C: "The"
            },
            correctAnswer: "A"
        },
        {
            question: "25. She is ___ most beautiful girl ever I have seen.",
            answers: {
                A: "An",
                B: "The",
                C: "A"
            },
            correctAnswer: "B"
        },

    ];

    // Kick things off
    buildQuiz();

    // Event listeners
    submitButton.addEventListener('click', showResults);
})();
(function() {
    function buildQuiz() {
        // variable to store the HTML output
        const output = [];

        // for each question...
        myQuestions.forEach(
            (currentQuestion, questionNumber) => {

                // variable to store the list of possible answers
                const answers = [];

                // and for each available answer...
                for (letter in currentQuestion.answers) {

                    // ...add an HTML radio button
                    answers.push(
                        `<label>
                <input type="radio" name="question${questionNumber}" value="${letter}">
                ${letter} :
                ${currentQuestion.answers[letter]}
              </label>`
                    );
                }

                // add this question and its answers to the output
                output.push(
                    `<div class="question"> ${currentQuestion.question} </div>
            <div style="padding-left:20px" class="answers"> ${answers.join('')} </div>`
                );
            }
        );

        // finally combine our output list into one string of HTML and put it on the page
        quizContainer.innerHTML = output.join('');
    }

    function showResults() {

        // gather answer containers from our quiz
        const answerContainers = quizContainer.querySelectorAll('.answers');

        // keep track of user's answers
        let numCorrect = 0;

        // for each question...
        myQuestions.forEach((currentQuestion, questionNumber) => {

            // find selected answer
            const answerContainer = answerContainers[questionNumber];
            const selector = `input[name=question${questionNumber}]:checked`;
            const userAnswer = (answerContainer.querySelector(selector) || {}).value;

            // if answer is correct
            if (userAnswer === currentQuestion.correctAnswer) {
                // add to the number of correct answers
                numCorrect++;

                // color the answers green
                answerContainers[questionNumber].style.color = 'green';

            }
            // if answer is wrong or blank
            else {
                // color the answers red
                answerContainers[questionNumber].style.color = 'red';
            }
        });

        // show number of correct answers out of total
        resultsContainer.innerHTML = ` You get ${numCorrect} out of ${myQuestions.length}`;
    }

    const quizContainer = document.getElementById('quiz');
    const resultsContainer = document.getElementById('results');
    const submitButton = document.getElementById('submit');
    const myQuestions = [{
            question: "1.The temperature is______three degree Celsius.",
            answers: {
                A: "Above",
                B: "Over",
                C: "Upper"
            },
            correctAnswer: "A"
        },
        {
            question: "2.	Jannat put veil______her dress.",
            answers: {
                A: "Top",
                B: "Over",
                C: "On"
            },
            correctAnswer: "B"
        },

        {
            question: "3.	She threw the ball______me.",
            answers: {
                A: "On",
                B: "To",
                C: "Over"
            },
            correctAnswer: "A"
        },

        {
            question: "4.	This assignment was given on the effect of free recall_____learning.",
            answers: {
                A: "with",
                B: "On",
                C: "Under"
            },
            correctAnswer: "B"
        },
        {
            question: "5.	The girl_____blue sari is my girlfriend.",
            answers: {
                A: "To",
                B: "In",
                C: "With"
            },
            correctAnswer: "C"
        },

        {
            question: "6. This is the back part______this house.",
            answers: {
                A: "In",
                B: "Of",
                C: "On"
            },
            correctAnswer: "B"
        },

        {
            question: "7.	The girl has taken_____her mother.",
            answers: {
                A: "With ",
                B: "To",
                C: "After"
            },
            correctAnswer: "C"
        },

        {
            question: "8.	The snake was killed____a bamboo.?",
            answers: {
                A: "For",
                B: "By",
                C: "with"
            },
            correctAnswer: "B"
        },

        {
            question: "9. _____her beauty, he wants to be something more.",
            answers: {
                A: "For",
                B: "With",
                C: "On"
            },
            correctAnswer: "A"
        },

        {
            question: "10.	A dishonest man is always greedy_____undue privileges.",
            answers: {
                A: "For",
                B: "With",
                C: "To"
            },
            correctAnswer: "A"
        },

        {
            question: "11. SAARC stands_____South Asian Association for Regional Co-operation",
            answers: {
                A: "On",
                B: "With",
                C: "For"
            },
            correctAnswer: "C"
        },

        {
            question: "12.	One should do one’s duty,_______?",
            answers: {
                A: "Should they ",
                B: "Shouldn't they ",
                C: "Shouldn't one"
            },
            correctAnswer: "C"
        },

        {
            question: "13.	He wouldn’t better leave the job,________?",
            answers: {
                A: "Will he",
                B: "Would he",
                C: "Wouldn't he"
            },
            correctAnswer: "B"
        },

        {
            question: "14.	I have been writing a grammar book since 2011,______?",
            answers: {
                A: "Have I",
                B: "Haven't I",
                C: "Had I"
            },
            correctAnswer: "C"
        },

        {
            question: "15.	The blind can read and write, _______?",
            answers: {
                A: "Can they",
                B: "Could they",
                C: "Can't they"
            },
            correctAnswer: "C"
        },

        {
            question: "16.	The poor are not always unhappy,______?",
            answers: {
                A: "Are they",
                B: "Aren't they",
                C: "Is they"
            },
            correctAnswer: "A"
        },

        {
            question: "17.	They had not better play at noon,______?",
            answers: {
                A: "Hadn't they",
                B: "Had they",
                C: "Have they"
            },
            correctAnswer: "B"
        },

        {
            question: "18.	There are three primary school in our village,______?",
            answers: {
                A: "Are there",
                B: "Is there",
                C: "Aren't there"
            },
            correctAnswer: "A"
        },
        {
            question: "19.	It isn’t a good idea,______?",
            answers: {
                A: "Is it",
                B: "Does it ",
                C: "Isn't it"
            },
            correctAnswer: "A"
        },

        {
            question: "20.	Some of you have done this nasty work,______?",
            answers: {
                A: "Have you",
                B: "Haven't you",
                C: "Hadn't you"
            },
            correctAnswer: "B"
        }



    ];

    // Kick things off
    buildQuiz();

    // Event listeners
    submitButton.addEventListener('click', showResults);
})();
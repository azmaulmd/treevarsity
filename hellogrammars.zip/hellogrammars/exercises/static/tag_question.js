(function() {
    function buildQuiz() {
        // variable to store the HTML output
        const output = [];

        // for each question...
        myQuestions.forEach(
            (currentQuestion, questionNumber) => {

                // variable to store the list of possible answers
                const answers = [];

                // and for each available answer...
                for (letter in currentQuestion.answers) {

                    // ...add an HTML radio button
                    answers.push(
                        `<label>
                <input type="radio" name="question${questionNumber}" value="${letter}">
                ${letter} :
                ${currentQuestion.answers[letter]}
              </label>`
                    );
                }

                // add this question and its answers to the output
                output.push(
                    `<div class="question"> ${currentQuestion.question} </div>
            <div style="padding-left:20px" class="answers"> ${answers.join('')} </div>`
                );
            }
        );

        // finally combine our output list into one string of HTML and put it on the page
        quizContainer.innerHTML = output.join('');
    }

    function showResults() {

        // gather answer containers from our quiz
        const answerContainers = quizContainer.querySelectorAll('.answers');

        // keep track of user's answers
        let numCorrect = 0;

        // for each question...
        myQuestions.forEach((currentQuestion, questionNumber) => {

            // find selected answer
            const answerContainer = answerContainers[questionNumber];
            const selector = `input[name=question${questionNumber}]:checked`;
            const userAnswer = (answerContainer.querySelector(selector) || {}).value;

            // if answer is correct
            if (userAnswer === currentQuestion.correctAnswer) {
                // add to the number of correct answers
                numCorrect++;

                // color the answers green
                answerContainers[questionNumber].style.color = 'green';

            }
            // if answer is wrong or blank
            else {
                // color the answers red
                answerContainers[questionNumber].style.color = 'red';
            }
        });

        // show number of correct answers out of total
        resultsContainer.innerHTML = ` You get ${numCorrect} out of ${myQuestions.length}`;
    }

    const quizContainer = document.getElementById('quiz');
    const resultsContainer = document.getElementById('results');
    const submitButton = document.getElementById('submit');
    const myQuestions = [{
            question: "1.	Nipa gave me a nice gift,_______ ?",
            answers: {
                A: "Did she",
                B: "Didn’t she",
                C: "Does she"
            },
            correctAnswer: "B"
        },
        {
            question: "2.Tania sings a song,_______?",
            answers: {
                A: "Didn't she",
                B: "Doesn’t she",
                C: "Does she"
            },
            correctAnswer: "B"
        },

        {
            question: "3.	They don’t do this work,______?",
            answers: {
                A: "Do they",
                B: "Don't they",
                C: "Does they"
            },
            correctAnswer: "A"
        },

        {
            question: "4.	He throws a ball to me, doesn’t he?",
            answers: {
                A: "Didn't he",
                B: "Doesn't he",
                C: "Does she"
            },
            correctAnswer: "B"
        },
        {
            question: "5.	The road was wet and muddy,______?",
            answers: {
                A: "Was it ",
                B: "Wasn't it ",
                C: "Wasn't that"
            },
            correctAnswer: "B"
        },

        {
            question: "6.	Give me some money to buy a set of books,_____?.",
            answers: {
                A: "Could you",
                B: "Can you",
                C: "Would you"
            },
            correctAnswer: "A"
        },

        {
            question: "7.	Let’s go to a study tour,____?",
            answers: {
                A: "Should we ",
                B: "Shouldn't we ",
                C: "Shall we"
            },
            correctAnswer: "C"
        },

        {
            question: "8.	Don’t do this work again,______?",
            answers: {
                A: "Won't you",
                B: "Will you",
                C: "Don't you"
            },
            correctAnswer: "B"
        },

        {
            question: "9.	Some of you have done this nasty work,_______?",
            answers: {
                A: "Have you",
                B: "Haven't you",
                C: "Haven't they"
            },
            correctAnswer: "B"
        },

        {
            question: "10.	There are three primary school in our village,________?",
            answers: {
                A: "Aren't there",
                B: "isn't there",
                C: "Are there"
            },
            correctAnswer: "A"
        },

        {
            question: "11.	How beautiful the girl is,________?",
            answers: {
                A: "Is she",
                B: "Isn't she",
                C: "Aren't she"
            },
            correctAnswer: "B"
        },

        {
            question: "12.	One should do one’s duty,_______?",
            answers: {
                A: "Should they ",
                B: "Shouldn't they ",
                C: "Shouldn't one"
            },
            correctAnswer: "C"
        },

        {
            question: "13.	He wouldn’t better leave the job,________?",
            answers: {
                A: "Will he",
                B: "Would he",
                C: "Wouldn't he"
            },
            correctAnswer: "B"
        },

        {
            question: "14.	I have been writing a grammar book since 2011,______?",
            answers: {
                A: "Have I",
                B: "Haven't I",
                C: "Had I"
            },
            correctAnswer: "C"
        },

        {
            question: "15.	The blind can read and write, _______?",
            answers: {
                A: "Can they",
                B: "Could they",
                C: "Can't they"
            },
            correctAnswer: "C"
        },

        {
            question: "16.	The poor are not always unhappy,______?",
            answers: {
                A: "Are they",
                B: "Aren't they",
                C: "Is they"
            },
            correctAnswer: "A"
        },

        {
            question: "17.	They had not better play at noon,______?",
            answers: {
                A: "Hadn't they",
                B: "Had they",
                C: "Have they"
            },
            correctAnswer: "B"
        },

        {
            question: "18.	There are three primary school in our village,______?",
            answers: {
                A: "Are there",
                B: "Is there",
                C: "Aren't there"
            },
            correctAnswer: "C"
        },
        {
            question: "19.	It isn’t a good idea,______?",
            answers: {
                A: "Is it",
                B: "Does it ",
                C: "Isn't it"
            },
            correctAnswer: "A"
        },

        {
            question: "20.	Some of you have done this nasty work,______?",
            answers: {
                A: "Have you",
                B: "Haven't you",
                C: "Hadn't you"
            },
            correctAnswer: "B"
        }



    ];

    // Kick things off
    buildQuiz();

    // Event listeners
    submitButton.addEventListener('click', showResults);
})();
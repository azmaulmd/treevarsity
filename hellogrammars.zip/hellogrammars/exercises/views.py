
from flask import Blueprint, render_template

exercises = Blueprint('exercises', __name__, static_folder='static', template_folder='templates',
                      url_prefix='/exercises')


@exercises.route('/')
def exercises_home():
    title = "Exercises | Article"
    return render_template('exercises/the_article.html', title=title)


@exercises.route('/the-article-exercises')
def the_article(): 
    title = " Exercises | Article"
    return render_template('exercises/the_article.html', title=title)


@exercises.route('/right-form-of-verbs-exercise')
def right_form_of_verb(): 
    title = "Exercises  | Right form of verbs"
    return render_template('exercises/right_form_of_verb.html', title = title)


@exercises.route('/tag-question-exercises')
def tag_question():
    title = "Exercises | Tag question"
    return render_template('exercises/tag_question.html', title = title)


@exercises.route('/preposition-exercises')
def preposition(): 
    title = "Exercises | Preposition"
    return render_template('exercises/preposition.html', title = title)
from flask import Blueprint, render_template

vocabulary = Blueprint('vocabulary', __name__, template_folder='templates', static_folder='static',
                       url_prefix="/vocabulary")


@vocabulary.route('/')
def vocabulary_home():
    title = "Hellogrammars | Vocabulary"
    return render_template('vocabulary/name_of_organs.html', title=title)


@vocabulary.route('/name-of-organs')
def name_of_organs():
    title = "Hellogrammars | Name of Organs"
    return render_template('vocabulary/name_of_organs.html' ,title=title)  


@vocabulary.route('/beats-birds-of-organs')
def beats_birds_of_organs(): 
    title = "Vocabulary | Beats-birds of organs"
    return render_template('vocabulary/beats_birds_of_organs.html', title=title)
@vocabulary.route('/different-stages-of-human-life')
def different_stages_of_human_life():
    title = "Hellogrammars | Different stages of human life"
    return render_template('vocabulary/different_stages_of_human_life.html' ,title=title)



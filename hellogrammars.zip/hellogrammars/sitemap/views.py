from flask import Blueprint, render_template

sitemap = Blueprint('sitemap', __name__, static_folder='static', template_folder='templates', url_prefix='/sitemap')


@sitemap.route('/sitemap')
def sitemap_home():
    title = "Hellogrammars | Site Map"
    return render_template('sitemap/home.html', title=title)

function open_menu() {
    var x, m;
    m = (document.getElementById("leftmenu") || document.getElementById("sidenav"));

    if (m.style.display == "block") {
        close_menu();


    } else {

        m.style.display = "block";
        fix_sidemenu();


    }

}

function close_menu() {
    var m;
    m = (document.getElementById("leftmenu") || document.getElementById("sidenav"));
    m.style.display = "none";

}

if (window.addEventListener) {
    window.addEventListener("scroll", function() { fix_sidemenu(); });
    window.addEventListener("resize", function() { fix_sidemenu(); });
    window.addEventListener("touchmove", function() { fix_sidemenu(); });
    window.addEventListener("load", function() { fix_sidemenu(); });
} else if (window.attachEvent) {
    window.attachEvent("onscroll", function() { fix_sidemenu(); });
    window.attachEvent("onresize", function() { fix_sidemenu(); });
    window.attachEvent("ontouchmove", function() { fix_sidemenu(); });
    window.attachEvent("onload", function() { fix_sidemenu(); });
}


function fix_sidemenu() {
    var w, top;
    w = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
    top = scrolltop()
    if (top == 0) {
        document.getElementById("sidenav").style.top = "118px";
    }

    if (top > 0 && top < 73) {
        document.getElementById("sidenav").style.top = (119 - top) + "px";
    }
    if (top > 73) {
        document.getElementById("sidenav").style.top = "54px";
        if (w > 992) { document.getElementById("leftmenuinner").style.paddingTop = "54px"; }
        document.getElementById("belowtopnav").style.paddingTop = "54px";
        document.getElementById("topnav").style.position = "fixed";
        document.getElementById("googlesearch").style.position = "fixed";
        document.getElementById("googlesearch").style.top = "0";
        document.getElementById("topnav").style.top = "0";

    } else {
        if (w > 992) {
            document.getElementById("leftmenuinner").style.paddingTop = (119 - top) + "px";
        } else {
            document.getElementById("leftmenuinner").style.paddingTop = 0;
        }
        document.getElementById("belowtopnav").style.paddingTop = "0";
        document.getElementById("googlesearch").style.position = "absolute";
        document.getElementById("googlesearch").style.top = "";
        document.getElementById("topnav").style.position = "relative";

    }

}





function sidemenuitemintoview() {
    var a, b, i = 0;
    a = document.getElementById("leftmenuinnerinner");
    if (!a || !a.getElementsByClassName) { return false; }
    b = a.getElementsByClassName("active");
    if (b.length < 1) { return false; }
    while (!isIntoView(a, b[0])) {
        i++
        if (i > 1000) { break; }
        a.scrollTop += 10;
    }
}

function isIntoView(x, y) {
    var a = x.scrollTop;
    var b = a + window.innerHeight;
    var ytop = y.offsetTop;
    var ybottom = ytop + 140;
    return ((ybottom <= b) && (ytop >= a));
}

function scrolltop() {
    var top = 0;
    if (typeof(window.pageYOffset) == "number") {
        top = window.pageYOffset;
    } else if (document.body && document.body.scrollTop) {
        top = document.body.scrollTop;
    } else if (document.documentElement && document.documentElement.scrollTop) {
        top = document.documentElement.scrollTop;
    }
    return top;
}



function open_search(elmnt) {
    var a = document.getElementById("googlesearch");
    if (a.style.display == "") {
        a.style.display = "none";
        a.style.paddingRight = "";

    } else {
        a.style.display = "";
        if (window.innerWidth > 700) {
            a.style.width = "40%";
        } else {
            a.style.width = "80%";
        }
        /*  if (document.getElementById("gsc-i-id1")) { document.getElementById("gsc-i-id1").focus(); }
         elmnt.innerHTML = "<span style='font-family:verdana;font-weight:bold;'>X</span>"; */
        window.setTimeout(function() {
            if (document.getElementById("gsc-i-id1")) {
                document.getElementById("gsc-i-id1").focus();
            }
        }, 400);

    }
}

function w3_open() {
    var x = document.getElementById("myAccordion");
    if (x.style.display === 'none') {
        x.style.display = 'block';
        if (document.getElementById("navbtn_menu")) {
            document.getElementById("navbtn_menu").getElementsByTagName("i")[0].style.display = "none";
            document.getElementById("navbtn_menu").getElementsByTagName("i")[1].style.display = "inline";
        }
    } else {
        x.style.display = 'none';
        if (document.getElementById("navbtn_menu")) {
            document.getElementById("navbtn_menu").getElementsByTagName("i")[0].style.display = "inline";
            document.getElementById("navbtn_menu").getElementsByTagName("i")[1].style.display = "none";
        }
    }
}

function w3_close() {
    document.getElementById("myAccordion").style.display = "none";
    document.getElementById("navbtn_menu").getElementsByTagName("i")[0].style.display = "inline";
    document.getElementById("navbtn_menu").getElementsByTagName("i")[1].style.display = "none";

}
(function() {
    var x, y, i, a, aa, b, c, cc, d, dd, m;
    m = (document.getElementById("leftmenu") || document.getElementById("sidenav"));
    x = m.getElementsByTagName("A");
    dd = document.location.href;
    if (dd.indexOf("quiztest") > -1) {
        d = dd;
    } else {
        d = dd.split('?')[0]; // added split to show active regardless of parameters
    }
    for (i = 0; i < x.length; i++) {
        if (dd.indexOf("quiztest") > -1) {
            aa = x[i].href;
            //console.log("Haystack: " + d);
            //console.log("Needle: " + aa);
        } else {
            aa = x[i].href.split('?')[0]; // added split to show active regardless of parameters
        }
        if (d.indexOf(aa) >= 0) {
            x[i].className = "active";
            y = x[i].nextElementSibling;
            if (y && (y.className.indexOf("ref_overview") > -1 || y.className.indexOf("tut_overview") > -1)) {
                y.style.display = "block";
                if (y.className.indexOf("tut_overview") > -1) {
                    x[i].className = "active_overview";
                    y.getElementsByTagName("a")[0].className = "active";
                }
                if (x[i].addEventListener) {
                    cc = true;
                    x[i].addEventListener("click", function() {
                        if (cc == true) {
                            y.style.display = "none";
                            event.preventDefault();
                            cc = false;
                        } else {
                            y.style.display = "block";
                            cc = true;
                            event.preventDefault();
                        }
                    });
                }
            } else if (x[i].parentElement.className.indexOf("ref_overview") > -1) {
                x[i].parentElement.style.display = "block";
                x[i].parentElement.previousElementSibling.className = "activesub";
            } else if (x[i].parentElement.className.indexOf("tut_overview") > -1) {
                x[i].parentElement.style.display = "block";
                x[i].parentElement.previousElementSibling.className = "active_overview";
            }
            break;
        } else if (d.indexOf("/tags/att_") > -1) {
            c = d.substring(d.indexOf("/tags/att_") + 10, d.lastIndexOf("_"));
            if (x[i].href == d.substr(0, d.indexOf("/tags/")) + "/tags/tag_" + c + ".asp") {
                x[i].className = "active";
            }
        } else if (d.indexOf("/howto/default_page") > -1) {
            if (x[i].href.indexOf("default.asp") > -1) {
                x[i].className = "active";
            }
        }
    }
    sidemenuitemintoview()

    if (window.addEventListener) {
        document.getElementById("main").addEventListener("click", w3_close, true);
        m.addEventListener("click", w3_close, true);
        document.getElementById("right").addEventListener("click", w3_close, true);
        document.getElementById("main").addEventListener("wheel", w3_close, true);
        document.getElementById("main").addEventListener("touchstart", w3_close, true);
    } else if (window.attachEvent) {
        document.getElementById("main").attachEvent("onclick", w3_close);
        m.attachEvent("onclick", w3_close);
        document.getElementById("right").attachEvent("onclick", w3_close);
    }
    if ('ontouchstart' in window || 'onmsgesturechange' in window) {
        document.getElementById("leftmenuinnerinner").style.overflowY = "scroll";
    }
})();
from flask import Blueprint, render_template


about = Blueprint('about', __name__, static_folder='static', template_folder='templates', url_prefix='/about')


@about.route('/about-hellogrammars')
def about_home():
    title = "Hellogramamrs | About"
    return render_template('about/home.html', title=title)


@about.route("/terms-of-use")
def terms_of_use():
    title = "Hellogrammars | Terms of use"
    return render_template("about/terms_of_use.html", title=title)


@about.route("/privacy-policy")
def privacy_policy():
    title = "Hellogrammars | Privacy policy"
    return render_template("about/privacy_policy.html", title=title)


